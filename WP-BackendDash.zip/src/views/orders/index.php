<?php

echo do_shortcode('[wpdatatable id=3]');